#include "main.h"


int main(int argc, char** argv){
	if(argc < 2){
		PRINT_ERR("arguments not valid");
		exit(0);
	}
	if(!fileNameCheck(argv[1])){
		PRINT_ERR("File must be of type '.sle' or '.SLE'\n");
	}
	input_file = argv[1];
	FILE_OPEN_CHEK(yyin, argv[1]);

	int err = yyparse();
    if(err){
      fprintf(stdout,"parse didn't success\n");
    }else{
      fprintf(stdout,"successful parseion\n");
    }

    return 0;
}

/* Check if the file name is correct */
bool fileNameCheck(char* fileName){
	char * ext = strchr(fileName+1,'.') + 1;
    if(ext == NULL || (strcmp("sle",ext) && strcmp("SLE",ext))){
		return FALSE;
	}
	return TRUE;
}

/**
 * allocate and check if the allocation is succeaded
 */
void* checked_malloc(unsigned int size){
	void * ret;
	ret = malloc(size);
	if (!ret) {
		fprintf(stderr, " ERROR: Memory allocation error");
		exit (1);
	}
	return ret;
}

//////////////////////////////////////////////////////////////////////////////
/**
 * inters element to the symbol table
 * if the element is alraedy exist do non
 */
void insertToTable(const char* id, Number type){
	Node* isExist = findById(id);
	if(isExist != NULL){
		if(isExist->visited == FALSE){
			fprintf(stderr, " ERROR: Symbol %s allready in the symbol table.\n",id);
			isExist->visited = TRUE;
		}
    	return;
	}
	Node* new_elem = ALLOC(Node,1);
	strcpy(new_elem->id, id);
	new_elem->attr.type = type.type;
	new_elem->visited = FALSE;
	new_elem->next = smb_list.head;
	smb_list.head = new_elem;
}

/**
 * Assigning Operation
 */
void assingOp(const char* id, Number val){
	Node* isExist = findById(id);
	if(!isExist){\
		CHECK_EXIST(isExist, id);
		return;
	}
	if(isExist->attr.type == FLOAT){
    	isExist->attr.fval = val.type==FLOAT? val.fval:(float)val.ival;
  	}else{
   	isExist->attr.ival = val.type==FLOAT? (int)val.fval:val.ival;
	}
  return;
}

void getOpp(const char* id, Number val){
	Node* isExist = findById(id);
	CHECK_EXIST(isExist, id);

	//////////////////////////////////////////////////////////////////////////
}

/**
 * search the element by its ID
 * return Node* elem or NULL if not found 
 */
Node* findById(const char* id){
	Node* temp_head = smb_list.head;
	while (temp_head)
	{
		if(!strcmp(id,temp_head->id)){
			return temp_head;
		}
		temp_head = temp_head->next;
	}
	return NULL;
	
}


/**
 * return the value of the id 
 */
Number getValueById(const char* id){
	Node* isExist = findById(id);
	if(!isExist){
		CHECK_EXIST(isExist, id);
		Number err;
		err.type = ERROR;
		return err;
	}
	return isExist->attr;
}

/**
 * checking if an undifinded variable was writen int the code before
 * if not insert it to the undefinded list
 */
bool isUndifindedExist(const char* id){

	undeclerd* head = error_list.head;
	while(head)
	{
		if(!strcmp(id, head->id)){
			return TRUE;
		}
		head = head->next;
	}
	return FALSE;
}

/**
 * insert to the undefinded list
 */
void insertToUndeclerdTable(const char* id){
	undeclerd* new_name = ALLOC(undeclerd, 1);
	strcpy(new_name->id, id);
	new_name->next = error_list.head;
	error_list.head = new_name;
}


/**
 * printing an expration
 */
void printExpression(Number num){
  	switch(num.type){
    	case INTEGER:
    	printf("%d",num.ival);
    	return;
		case FLOAT:
		printf("%f",num.fval);
		return;
		case ERROR:
		return;
  }
}


/**
 * booleane Exptarion
 */
bool boolExp(Number lhs, char opr, Number rhs){
  double left = lhs.type == INTEGER? lhs.ival:lhs.fval;
  double right = rhs.type == INTEGER? rhs.ival:rhs.fval;
  switch( opr ){
    case '<':
    	return left < right? TRUE:FALSE;
    case '>':
    	return left > right? TRUE:FALSE;
    case '!':
    	return left != right? TRUE:FALSE;
    case '=':
    	return left == right? TRUE:FALSE;
    case '&':
    	return left && right? TRUE:FALSE;
    case '~':
    	return left || right? TRUE:FALSE;
  }
}


/**
 * ADD Operation '-', '+'
 */
Number addOp(Number lhs, char opr, Number rhs){
	double left = lhs.type == INTEGER? (double)lhs.ival:lhs.fval;
  	double right = rhs.type == INTEGER? (double)rhs.ival:rhs.fval;
	Number res;
	right = (opr == '-') ? -right:right;
	double ans  = left + right;
	if(lhs.type == INTEGER && rhs.type == INTEGER){
		res.type == INTEGER;
		res.ival = (int)ans;
	}else{
		res.type == FLOAT;
		res.fval = ans;
	}
	return res;
}

/**
 * MULL Operation '*', '/', '%'
 */
Number mulOp(Number lhs, char opr, Number rhs){
	double left = lhs.type == INTEGER? (double)lhs.ival:lhs.fval;
  	double right = rhs.type == INTEGER? (double)rhs.ival:rhs.fval;
	Number res;
	if(lhs.type == INTEGER && rhs.type == INTEGER){
		res.type == INTEGER;
	}
	switch (opr){
		case '*':
			(res.type == INTEGER) ? (res.ival = (int)(left * right)) : (res.fval = left * right);
			break;
		case '/':
			if(right == 0){
				fprintf(stderr, " ERROR: can't divide by zero.\n");
				break;
			}
			(res.type == INTEGER) ? (res.ival = (int)(left / right)) : (res.fval = left / right);
			break;
		case '%':
			if(res.type == FLOAT){
				fprintf(stderr, " ERROR: can't operate MOD on float values.\n");
				break;
			}else{
				res.ival = (int)left % (int)right;
				break;
			}
	}
	return res;
}