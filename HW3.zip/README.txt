yair pinhas 307926048
dor david 316371103